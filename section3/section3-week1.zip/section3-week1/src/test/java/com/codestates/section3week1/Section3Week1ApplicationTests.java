package com.codestates.section3week1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Section3Week1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
