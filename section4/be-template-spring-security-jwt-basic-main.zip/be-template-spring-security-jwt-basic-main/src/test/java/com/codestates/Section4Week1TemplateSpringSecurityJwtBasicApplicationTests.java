package com.codestates;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Section4Week1TemplateSpringSecurityJwtBasicApplicationTests {

	@Test
	void contextLoads() {
	}

}
